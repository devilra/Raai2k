const { DataTypes } = require("sequelize");
const sequelize = require("../../config/db");
const { cloudinary } = require("../../config/cloudinaryConfig");

const WhyChooseUs = sequelize.define(
  "WhyChooseUs",
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },

    // 1. 🖼️ Feature Image (Icon-க்கு பதில் சிறிய புகைப்படம்)
    image: {
      type: DataTypes.STRING,
      allowNull: true,
    },

    // 💡 Cloudinary Public ID (நீக்குவதற்கும் அப்டேட் செய்வதற்கும்)
    publicId: {
      type: DataTypes.STRING,
      allowNull: true,
    },

    // 2. 🏷️ Page/Section Title (உதாரணம்: "Why Choose Us")
    pageTitle: {
      type: DataTypes.STRING(150),
      allowNull: false,
      defaultValue: "Why Choose raai2k",
    },

    // 4. 📝 Paragraph / Description (உதாரணம்: "Experienced in financial regulations...")
    description: {
      type: DataTypes.TEXT,
      allowNull: false,
    },

    // 🔹 வரிசைப்படுத்துவதற்கு (Ordering)
    order: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 1,
    },

    // 🔹 நிலை (Active or Inactive)
    isActive: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
  },
  {
    tableName: "why_choose_us",
    timestamps: true,

    hooks: {
      // Row நீக்கப்படும் போது Cloudinary-ல் இருந்தும் படத்தை நீக்க
      beforeDestroy: async (record) => {
        if (record.publicId) {
          try {
            await cloudinary.uploader.destroy(record.publicId);
            console.log(
              `WhyChoose image deleted from Cloudinary: ${record.publicId}`
            );
          } catch (error) {
            console.error("Cloudinary Delete Error:", error);
          }
        }
      },

      // படம் மாற்றப்பட்டால் பழைய படத்தை Cloudinary-ல் இருந்து நீக்க
      beforeUpdate: async (record) => {
        if (record.changed("publicId")) {
          const oldPublicId = record.previous("publicId");
          if (oldPublicId) {
            try {
              await cloudinary.uploader.destroy(oldPublicId);
              console.log(`Old WhyChoose image deleted: ${oldPublicId}`);
            } catch (error) {
              console.error("Cloudinary Update Delete Error:", error);
            }
          }
        }
      },
    },
  }
);

module.exports = WhyChooseUs;
